document.getElementById("contact-form").addEventListener("submit", function(event) {
  event.preventDefault(); 
  alert("Thank you for contacting me! Your message has been sent.");
});